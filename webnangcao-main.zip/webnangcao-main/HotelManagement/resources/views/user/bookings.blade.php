<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Đặt phòng</title>
</head>
<body>
    <h2>Đặt phòng khách sạn</h2>
    <p>Form đặt phòng sẽ được hiển thị ở đây.</p>
</body>
</html>
