<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Liên hệ</title>
</head>
<body>
    <h2>Liên hệ với chúng tôi</h2>
    <p>Thông tin liên hệ và form gửi phản hồi.</p>
</body>
</html>
