<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Trang chủ - Hotel Management</title>
</head>
<body>
    <h1>🏨 Hệ thống Quản lý Khách sạn</h1>
    <p>Chào mừng bạn đến với hệ thống quản lý khách sạn Laravel!</p>

    <nav>
        <a href="/">Trang chủ</a> |
        <a href="/rooms">Phòng</a> |
        <a href="/booking">Đặt phòng</a> |
        <a href="/contact">Liên hệ</a>
    </nav>
</body>
</html>
