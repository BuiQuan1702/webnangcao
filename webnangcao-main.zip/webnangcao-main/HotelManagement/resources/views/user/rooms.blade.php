<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Danh sách phòng</title>
</head>
<body>
    <h2>Danh sách các phòng</h2>
    <p>Hiển thị danh sách các phòng khách sạn tại đây.</p>
</body>
</html>
